
#include <iostream.h>

int main(int argc, char ** argv){
  int a,b,c;
  
  a = 3;
  b = 5;
  
  c = a && b;
  
  cout << "The value of c = " << c << endl;
}



